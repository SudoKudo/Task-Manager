package com.classproject.markngn.taskmanager;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {
    private EditText usrname, pword;
    private TextView forgetPass, newAccount;
    private Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        usrname = (EditText)findViewById(R.id.username);
        pword = (EditText)findViewById(R.id.password);
        forgetPass = (TextView)findViewById(R.id.passReset);
        newAccount = (TextView)findViewById(R.id.register);
        login = (Button)findViewById(R.id.LoginBT);

        forgetPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, PasswordResetActivity.class));
            }
        });

        newAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, RegistrationActivity.class));
            }
        });

    }

    public void onLogin(View view){
        String uname = usrname.getText().toString();
        String pass = pword.getText().toString();
        String type = "Login";

        LoginBackgroundWorker loginbackgroundWorker = new LoginBackgroundWorker(this);

        if(validateInput())
           startActivity(new Intent(LoginActivity.this, MainActivity.class));
            //loginbackgroundWorker.execute(uname, pass, type);

    }

    private boolean validateInput(){
        boolean result = true;
        String uname = usrname.getText().toString();
        String pass = pword.getText().toString();

        if(uname.isEmpty()) {
            usrname.setError("Invalid username!");
            return false;
        }
        if(pass.isEmpty()) {
            pword.setError("Invalid Password!");
            return false;
        }

        return result;
    }
}
