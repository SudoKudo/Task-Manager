package com.classproject.markngn.taskmanager;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {
    private EditText usrname, pword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        usrname = (EditText)findViewById(R.id.username);
        pword = (EditText)findViewById(R.id.password);

    }

    public void onLogin(View view){
        String uname = usrname.getText().toString();
        String pass = pword.getText().toString();
        String type = "Login";

        LoginBackgroundWorker loginbackgroundWorker = new LoginBackgroundWorker(this);
        loginbackgroundWorker.execute(uname, pass, type);

    }
}
